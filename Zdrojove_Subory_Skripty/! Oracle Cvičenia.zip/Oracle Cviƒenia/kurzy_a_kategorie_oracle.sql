
-- DROP TABLE kategorie; 
-- DROP TABLE kurzy; 

CREATE TABLE kategorie (
  id NUMBER PRIMARY KEY,
  nazov VARCHAR2(100)
);

CREATE TABLE kurzy (
  id NUMBER PRIMARY KEY,
  nazov VARCHAR2(100),
  kategoria_id NUMBER,
  FOREIGN KEY (kategoria_id) REFERENCES kategorie(id)
);

-- TRUNCATE TABLE kategorie;
-- TRUNCATE TABLE kurzy;


-- Vkladanie kategórií
INSERT ALL
  INTO kategorie (id, nazov) VALUES (1, 'Programovanie')
  INTO kategorie (id, nazov) VALUES (2, 'Analýza dát')
  INTO kategorie (id, nazov) VALUES (3, 'Webové technológie')
  INTO kategorie (id, nazov) VALUES (4, 'Databázy')
  INTO kategorie (id, nazov) VALUES (5, 'Softvérové inžinierstvo')
  INTO kategorie (id, nazov) VALUES (6, 'Bezpečnosť')
  INTO kategorie (id, nazov) VALUES (7, 'Cloud a DevOps')
  INTO kategorie (id, nazov) VALUES (8, 'Mobilné aplikácie')
  INTO kategorie (id, nazov) VALUES (9, 'UI/UX dizajn')
  INTO kategorie (id, nazov) VALUES (10, 'Testovanie softvéru')
SELECT * FROM dual;

INSERT ALL
  INTO kurzy (id, nazov, kategoria_id) VALUES (1, 'Python základy', 1)
  INTO kurzy (id, nazov, kategoria_id) VALUES (2, 'Python pre analytikov', 3)
  INTO kurzy (id, nazov, kategoria_id) VALUES (3, 'Java základy', 10)
  INTO kurzy (id, nazov, kategoria_id) VALUES (4, 'Java pokročilý', 8)
  INTO kurzy (id, nazov, kategoria_id) VALUES (5, 'JavaScript pre začiatočníkov', 10)
  INTO kurzy (id, nazov, kategoria_id) VALUES (6, 'HTML a CSS', 2)
  INTO kurzy (id, nazov, kategoria_id) VALUES (7, 'React framework', 5)
  INTO kurzy (id, nazov, kategoria_id) VALUES (8, 'SQL základy', 9)
  INTO kurzy (id, nazov, kategoria_id) VALUES (9, 'Oracle SQL', 9)
  INTO kurzy (id, nazov, kategoria_id) VALUES (10, 'MySQL databázy', 2)
  INTO kurzy (id, nazov, kategoria_id) VALUES (11, 'Git a verzovanie', 5)
  INTO kurzy (id, nazov, kategoria_id) VALUES (12, 'Docker pre vývojárov', 8)
  INTO kurzy (id, nazov, kategoria_id) VALUES (13, 'Kubernetes pre začiatočníkov', 2)
  INTO kurzy (id, nazov, kategoria_id) VALUES (14, 'Linux pre DevOps', 3)
  INTO kurzy (id, nazov, kategoria_id) VALUES (15, 'Bezpečnosť aplikácií', 5)
  INTO kurzy (id, nazov, kategoria_id) VALUES (16, 'Etický hacking', 9)
  INTO kurzy (id, nazov, kategoria_id) VALUES (17, 'Flutter mobilné aplikácie', 4)
  INTO kurzy (id, nazov, kategoria_id) VALUES (18, 'Android Studio', 3)
  INTO kurzy (id, nazov, kategoria_id) VALUES (19, 'UX dizajn v praxi', 2)
  INTO kurzy (id, nazov, kategoria_id) VALUES (20, 'Figma pre začiatočníkov', 6)
  INTO kurzy (id, nazov, kategoria_id) VALUES (21, 'Agilné metódy vývoja', 8)
  INTO kurzy (id, nazov, kategoria_id) VALUES (22, 'Scrum v tímoch', 7)
  INTO kurzy (id, nazov, kategoria_id) VALUES (23, 'Unit testovanie v Pythone', 4)
  INTO kurzy (id, nazov, kategoria_id) VALUES (24, 'Testovanie v Jave', 2)
  INTO kurzy (id, nazov, kategoria_id) VALUES (25, 'Cypress pre QA', 10)
  INTO kurzy (id, nazov, kategoria_id) VALUES (26, 'PostgreSQL pokročilý', 5)
  INTO kurzy (id, nazov, kategoria_id) VALUES (27, 'MongoDB úvod', 8)
  INTO kurzy (id, nazov, kategoria_id) VALUES (28, 'Power BI pre analytikov', 4)
  INTO kurzy (id, nazov, kategoria_id) VALUES (29, 'Data Science v Pythone', 4)
  INTO kurzy (id, nazov, kategoria_id) VALUES (30, 'Pandas knižnica', 4)
  INTO kurzy (id, nazov, kategoria_id) VALUES (31, 'Jira pre manažérov', 6)
  INTO kurzy (id, nazov, kategoria_id) VALUES (32, 'CI/CD pipeline', 7)
  INTO kurzy (id, nazov, kategoria_id) VALUES (33, 'AWS cloud základy', 3)
  INTO kurzy (id, nazov, kategoria_id) VALUES (34, 'Azure pre vývojárov', 10)
  INTO kurzy (id, nazov, kategoria_id) VALUES (35, 'Spring framework', 2)
  INTO kurzy (id, nazov, kategoria_id) VALUES (36, 'Hibernate ORM', 7)
  INTO kurzy (id, nazov, kategoria_id) VALUES (37, 'Web API s Flaskom', 4)
  INTO kurzy (id, nazov, kategoria_id) VALUES (38, 'REST API v Jave', 9)
  INTO kurzy (id, nazov, kategoria_id) VALUES (39, 'Next.js framework', 1)
  INTO kurzy (id, nazov, kategoria_id) VALUES (40, 'Základy HTML5', 9)
  INTO kurzy (id, nazov, kategoria_id) VALUES (41, 'CSS pre pokročilých', 1)
  INTO kurzy (id, nazov, kategoria_id) VALUES (42, 'React Native', 6)
  INTO kurzy (id, nazov, kategoria_id) VALUES (43, 'Bootstrap framework', 4)
  INTO kurzy (id, nazov, kategoria_id) VALUES (44, 'SQL optimalizácia', 2)
  INTO kurzy (id, nazov, kategoria_id) VALUES (45, 'Testovanie bezpečnosti', 5)
  INTO kurzy (id, nazov, kategoria_id) VALUES (46, 'DevSecOps úvod', 1)
  INTO kurzy (id, nazov, kategoria_id) VALUES (47, 'Cloud architektúra', 6)
  INTO kurzy (id, nazov, kategoria_id) VALUES (48, 'iOS vývoj v Swift', 4)
  INTO kurzy (id, nazov, kategoria_id) VALUES (49, 'Kotlin základy', 4)
  INTO kurzy (id, nazov, kategoria_id) VALUES (50, 'Blender 3D základy', 9)
SELECT * FROM dual;
