
-- 1. INNER JOIN – iba kurzy, ktoré majú platnú kategóriu
SELECT k.id, k.nazov AS kurz, kat.nazov AS kategoria
FROM kurzy k
INNER JOIN kategorie kat ON k.kategoria_id = kat.id;

-- 2. LEFT JOIN – všetky kurzy, aj tie bez kategórie
SELECT k.id, k.nazov AS kurz, kat.nazov AS kategoria
FROM kurzy k
LEFT JOIN kategorie kat ON k.kategoria_id = kat.id;

-- 3. RIGHT JOIN – všetky kategórie, aj bez kurzov
SELECT k.id, k.nazov AS kurz, kat.nazov AS kategoria
FROM kurzy k
RIGHT JOIN kategorie kat ON k.kategoria_id = kat.id;

-- 4. FULL OUTER JOIN – všetko z oboch strán, vrátane nezhôd
SELECT k.id, k.nazov AS kurz, kat.nazov AS kategoria
FROM kurzy k
FULL OUTER JOIN kategorie kat ON k.kategoria_id = kat.id;

-- 5. CROSS JOIN – kartézsky súčin
SELECT k.nazov AS kurz, kat.nazov AS kategoria
FROM kurzy k
CROSS JOIN kategorie kat;

-- 6. JOIN + WHERE – filtrovanie podľa názvu kategórie
SELECT k.nazov AS kurz, kat.nazov AS kategoria
FROM kurzy k
JOIN kategorie kat ON k.kategoria_id = kat.id
WHERE kat.nazov = 'Programovanie';
